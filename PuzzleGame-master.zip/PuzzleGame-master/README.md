# PuzzleGame

<img
  src="/screen_shot/1.png"
  alt="Screen Shot 1"
  title="Screen Shot 1"
  style="display: inline-block; margin: 0 auto; height: 680px; width: 380px">


<img
  src="/screen_shot/2.png"
  alt="Screen Shot 2"
  title="Screen Shot 2"
  style="display: inline-block; margin: 0 auto; height: 680px; width: 380px">
